import React, { Component } from "react";

export class child extends Component {
  render() {
    return <div></div>;
  }
}

export default child;
